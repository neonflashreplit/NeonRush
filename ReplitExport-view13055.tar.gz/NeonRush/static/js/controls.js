class Controls {
    constructor(game) {
        this.game = game;
        this.touchStartX = null;
        this.touchStartY = null;
        this.isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
        this.setupControls();
    }

    setupControls() {
        if (this.isMobile) {
            this.setupMobileControls();
        } else {
            this.setupKeyboardControls();
        }

        // Retry button
        document.getElementById('retry-button').addEventListener('click', () => {
            this.game.restart();
        });

        // Share button
        document.getElementById('share-button').addEventListener('click', () => {
            const score = this.game.score;
            const text = `I scored ${score} points in Neon Rush! Can you beat my score?`;
            navigator.clipboard.writeText(text).then(() => {
                alert('Score copied to clipboard!');
            });
        });
    }

    setupKeyboardControls() {
        document.addEventListener('keydown', (e) => {
            if (!this.game.isGameOver) {
                switch(e.key) {
                    case 'ArrowLeft':
                    case 'a':
                    case 'A':
                        e.preventDefault();
                        this.game.movePlayer('left');
                        break;
                    case 'ArrowRight':
                    case 'd':
                    case 'D':
                        e.preventDefault();
                        this.game.movePlayer('right');
                        break;
                    case 'w':
                    case 'W':
                        e.preventDefault();
                        this.game.movePlayer('up');
                        break;
                    case 's':
                    case 'S':
                        e.preventDefault();
                        this.game.movePlayer('down');
                        break;
                }
            }
        });
    }

    setupMobileControls() {
        const mobileControls = document.querySelector('.mobile-controls');

        let touchStartTime;
        let lastTap = 0;

        mobileControls.addEventListener('touchstart', (e) => {
            e.preventDefault();
            touchStartTime = Date.now();
            const touch = e.touches[0];
            const rect = mobileControls.getBoundingClientRect();

            // Calculate touch position relative to screen
            const touchX = touch.clientX - rect.left;
            const touchY = touch.clientY - rect.top;

            // Determine which section of the screen was touched
            const horizontalSection = touchX / rect.width;
            const verticalSection = touchY / rect.height;

            // Move based on screen section touched
            if (!this.game.isGameOver) {
                if (horizontalSection < 0.3) {
                    this.game.movePlayer('left');
                } else if (horizontalSection > 0.7) {
                    this.game.movePlayer('right');
                }

                if (verticalSection < 0.3) {
                    this.game.movePlayer('up');
                } else if (verticalSection > 0.7) {
                    this.game.movePlayer('down');
                }
            }
        }, { passive: false });

        // Prevent default touch behaviors
        mobileControls.addEventListener('touchmove', (e) => {
            e.preventDefault();
        }, { passive: false });

        mobileControls.addEventListener('touchend', (e) => {
            e.preventDefault();
        }, { passive: false });
    }
}