class Game {
    constructor() {
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.resizeCanvas();

        this.particles = new ParticleSystem(this.canvas, this.ctx);

        // Horizontal lanes
        this.lanes = [
            this.canvas.width * 0.25,
            this.canvas.width * 0.5,
            this.canvas.width * 0.75
        ];

        // Vertical positions
        this.verticalPositions = [
            this.canvas.height * 0.7,  // Bottom
            this.canvas.height * 0.5,  // Middle
            this.canvas.height * 0.3   // Top
        ];

        this.player = {
            x: this.lanes[1],
            y: this.verticalPositions[0], // Start at bottom position
            width: 30,
            height: 30,
            trail: [],
            blurAmount: 0
        };

        this.controls = new Controls(this);

        window.addEventListener('resize', () => {
            this.resizeCanvas();
            this.player.x = this.lanes[this.currentLane];
            this.player.y = this.verticalPositions[this.currentVertical];
        });

        this.milestones = [10, 100, 500, 1000];
        this.speedMultipliers = {
            10: 1.2,
            100: 1.5,
            500: 2,
            1000: 2.5
        };
        this.achievedMilestones = new Set();
        this.lastSpawnTime = Date.now();
        this.spawnInterval = 2000;
        this.screenShakeTime = 0;
        this.nearMissDistance = 50;

        // Add color schemes for obstacles
        this.obstacleColors = [
            '255, 0, 255',  // Pink
            '255, 0, 0',    // Red
            '0, 255, 255',  // Cyan
            '255, 165, 0',  // Orange
            '255, 255, 0'   // Yellow
        ];

        // Special block colors with their effects
        this.specialBlockColors = {
            'green': '0, 255, 0',
            'white': '255, 255, 255',
            'silver': '192, 192, 192',
            'gold': '255, 215, 0'
        };

        this.currentColorIndex = 0;
        this.colorChangeInterval = 1000; // Change color every 1000ms
        this.lastColorChange = Date.now();

        this.init();
    }

    init() {
        this.currentLane = 1;
        this.currentVertical = 0; // Start at bottom position
        this.score = 0;
        this.baseSpeed = 1;
        this.speed = this.baseSpeed;
        this.speedIncrement = 0.02;
        this.isGameOver = false;
        this.obstacles = [];
        this.highScore = localStorage.getItem('highScore') || 0;
        this.achievedMilestones.clear();

        document.getElementById('high-score-value').textContent = this.highScore;
        document.getElementById('achievements-list').innerHTML = ''; // Clear achievements list
        this.updateNextAchievement();
        this.gameLoop();
    }

    getNextMilestone() {
        return this.milestones.find(milestone => !this.achievedMilestones.has(milestone)) || this.milestones[this.milestones.length - 1];
    }

    updateNextAchievement() {
        const nextMilestone = this.getNextMilestone();
        const prevMilestone = this.milestones[this.milestones.indexOf(nextMilestone) - 1] || 0;
        const progress = ((this.score - prevMilestone) / (nextMilestone - prevMilestone)) * 100;

        document.getElementById('next-milestone').textContent = `${nextMilestone} points`;
        document.getElementById('achievement-progress').style.width = `${Math.min(100, Math.max(0, progress))}%`;
    }

    addScreenShake() {
        this.screenShakeTime = 10;
        document.getElementById('game-container').classList.add('screen-shake');
        setTimeout(() => {
            document.getElementById('game-container').classList.remove('screen-shake');
        }, 500);
    }

    celebrateAchievement(milestone) {
        // Create firework effect
        const colors = ['255, 0, 255', '0, 255, 255', '255, 255, 0'];

        // Multiple firework bursts
        for (let i = 0; i < 3; i++) {
            setTimeout(() => {
                const x = Math.random() * this.canvas.width;
                const y = Math.random() * (this.canvas.height / 2);
                const color = colors[Math.floor(Math.random() * colors.length)];
                this.particles.emit(x, y, color, 30);
            }, i * 300);
        }

        // Update achievements list
        const achievementsList = document.getElementById('achievements-list');
        const achievementItem = document.createElement('div');
        achievementItem.className = 'achievement-item';
        achievementItem.textContent = `${milestone} Points!`;
        achievementsList.appendChild(achievementItem);

        // Show achievement message
        const message = document.createElement('div');
        message.className = 'achievement-message';
        message.textContent = `Achievement: ${milestone} Points!`;
        document.body.appendChild(message);

        // Remove message after animation
        setTimeout(() => {
            message.remove();
        }, 2000);
    }

    checkAchievements() {
        this.milestones.forEach(milestone => {
            if (this.score >= milestone && !this.achievedMilestones.has(milestone)) {
                this.celebrateAchievement(milestone);
                this.achievedMilestones.add(milestone);
                this.speed = this.calculateSpeed();
                this.spawnInterval = Math.max(500, 2000 - (this.score * 0.5));
                this.addScreenShake();
            }
        });
        this.updateNextAchievement();
    }

    calculateSpeed() {
        let multiplier = 1;
        this.achievedMilestones.forEach(milestone => {
            multiplier = Math.max(multiplier, this.speedMultipliers[milestone] || 1);
        });
        // Reduced speed increment for smoother progression
        return (this.baseSpeed + (this.score * this.speedIncrement * 0.7)) * multiplier;
    }

    updatePlayerTrail() {
        this.player.trail.unshift({ x: this.player.x, y: this.player.y });
        if (this.player.trail.length > 5) {
            this.player.trail.pop();
        }
    }

    checkNearMiss(obstacle) {
        const dx = Math.abs(this.player.x - obstacle.x);
        const dy = Math.abs(this.player.y - obstacle.y);
        if (dx < this.nearMissDistance && dy < this.nearMissDistance && !this.isGameOver) {
            this.addScreenShake();
            // Add particles for near miss effect
            this.particles.emit(obstacle.x, obstacle.y, '255, 255, 255', 10);
        }
    }

    spawnObstacle() {
        const currentTime = Date.now();
        if (currentTime - this.lastSpawnTime > this.spawnInterval) {
            const lane = Math.floor(Math.random() * 3);

            // Determine if this should be a special block (10% chance)
            const isSpecial = Math.random() < 0.1;
            let color;

            if (isSpecial) {
                // Select a special color based on score
                if (this.score >= 1000) {
                    color = this.specialBlockColors.gold;
                } else if (this.score >= 500) {
                    color = this.specialBlockColors.silver;
                } else if (this.score >= 100) {
                    color = this.specialBlockColors.white;
                } else {
                    color = this.specialBlockColors.green;
                }
            } else {
                // Cycle through normal colors
                if (currentTime - this.lastColorChange > this.colorChangeInterval) {
                    this.currentColorIndex = (this.currentColorIndex + 1) % this.obstacleColors.length;
                    this.lastColorChange = currentTime;
                }
                color = this.obstacleColors[this.currentColorIndex];
            }

            this.obstacles.push({
                x: this.lanes[lane],
                y: -30,
                width: 30,
                height: 30,
                color: color,
                isSpecial: isSpecial
            });
            this.lastSpawnTime = currentTime;
        }
    }

    update() {
        if (this.isGameOver) return;

        // Update horizontal position with slower, smoother movement
        const targetX = this.lanes[this.currentLane];
        const dx = targetX - this.player.x;
        this.player.x += dx * 0.1; // Reduced from 0.2 for smoother movement

        // Update vertical position with slower, smoother movement
        const targetY = this.verticalPositions[this.currentVertical];
        const dy = targetY - this.player.y;
        this.player.y += dy * 0.1; // Reduced from 0.2 for smoother movement

        this.player.blurAmount = Math.sqrt(dx * dx + dy * dy) * 0.3; // Reduced blur effect

        this.updatePlayerTrail();

        this.obstacles.forEach((obstacle, index) => {
            // Slower obstacle movement
            obstacle.y += this.speed * 0.8; // Reduced speed multiplier
            this.checkNearMiss(obstacle);

            if (this.checkCollision(this.player, obstacle)) {
                this.gameOver();
            }

            if (obstacle.y > this.canvas.height) {
                this.obstacles.splice(index, 1);
                this.score++;
                this.checkAchievements();
                this.speed = this.calculateSpeed();
            }
        });

        this.spawnObstacle();
        this.particles.update();
        document.getElementById('score-value').textContent = this.score;
    }

    checkCollision(a, b) {
        return a.x < b.x + b.width &&
               a.x + a.width > b.x &&
               a.y < b.y + b.height &&
               a.y + a.height > b.y;
    }

    draw() {
        this.ctx.fillStyle = '#000';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Draw lane lines with glow effect
        this.lanes.forEach(lane => {
            this.ctx.beginPath();
            this.ctx.strokeStyle = 'rgba(0, 255, 255, 0.2)';
            this.ctx.shadowBlur = 10;
            this.ctx.shadowColor = '#0ff';
            this.ctx.moveTo(lane, 0);
            this.ctx.lineTo(lane, this.canvas.height);
            this.ctx.stroke();
            this.ctx.shadowBlur = 0;
        });

        // Draw player trail
        this.player.trail.forEach((pos, index) => {
            const alpha = (5 - index) / 5;
            this.ctx.fillStyle = `rgba(0, 255, 255, ${alpha * 0.5})`;
            this.ctx.beginPath();
            this.ctx.arc(pos.x, pos.y + this.player.height/2, 
                        this.player.width/2 * (1 - index/5), 0, Math.PI * 2);
            this.ctx.fill();
        });

        // Draw player with glow effect
        this.ctx.shadowBlur = 20;
        this.ctx.shadowColor = '#0ff';
        this.ctx.fillStyle = '#0ff';
        this.ctx.fillRect(
            this.player.x - this.player.width/2,
            this.player.y,
            this.player.width,
            this.player.height
        );
        this.ctx.shadowBlur = 0;

        // Draw obstacles with their specific colors and glow effects
        this.obstacles.forEach(obstacle => {
            this.ctx.shadowBlur = obstacle.isSpecial ? 25 : 15;
            this.ctx.shadowColor = `rgba(${obstacle.color}, 1)`;
            this.ctx.fillStyle = `rgba(${obstacle.color}, 1)`;
            this.ctx.fillRect(
                obstacle.x - obstacle.width/2,
                obstacle.y,
                obstacle.width,
                obstacle.height
            );
        });
        this.ctx.shadowBlur = 0;

        this.particles.draw();
    }

    gameLoop() {
        this.update();
        this.draw();
        requestAnimationFrame(() => this.gameLoop());
    }

    gameOver() {
        this.isGameOver = true;
        if (this.score > this.highScore) {
            this.highScore = this.score;
            localStorage.setItem('highScore', this.highScore);
        }

        const gameOverScreen = document.getElementById('game-over');
        gameOverScreen.classList.remove('hidden');
        gameOverScreen.classList.add('visible');
        document.getElementById('final-score').textContent = this.score;
        document.getElementById('best-score').textContent = this.highScore;
        this.addScreenShake();
    }

    restart() {
        const gameOverScreen = document.getElementById('game-over');
        gameOverScreen.classList.remove('visible');
        gameOverScreen.classList.add('hidden');
        this.init();
    }

    resizeCanvas() {
        this.canvas.width = this.canvas.clientWidth;
        this.canvas.height = this.canvas.clientHeight;
        this.lanes = [
            this.canvas.width * 0.25,
            this.canvas.width * 0.5,
            this.canvas.width * 0.75
        ];
        this.verticalPositions = [
            this.canvas.height * 0.7,  // Bottom
            this.canvas.height * 0.5,  // Middle
            this.canvas.height * 0.3   // Top
        ];
    }

    movePlayer(direction) {
        switch(direction) {
            case 'left':
                if (this.currentLane > 0) {
                    this.currentLane--;
                    this.particles.emit(this.player.x, this.player.y, '0, 255, 255', 10);
                }
                break;
            case 'right':
                if (this.currentLane < 2) {
                    this.currentLane++;
                    this.particles.emit(this.player.x, this.player.y, '0, 255, 255', 10);
                }
                break;
            case 'up':
                if (this.currentVertical < 2) {
                    this.currentVertical++;
                    this.particles.emit(this.player.x, this.player.y, '0, 255, 255', 10);
                }
                break;
            case 'down':
                if (this.currentVertical > 0) {
                    this.currentVertical--;
                    this.particles.emit(this.player.x, this.player.y, '0, 255, 255', 10);
                }
                break;
        }
    }
}

window.addEventListener('load', () => {
    const game = new Game();
    window.gameInstance = game;
});